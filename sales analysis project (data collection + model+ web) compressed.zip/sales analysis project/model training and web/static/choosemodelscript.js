document.addEventListener('DOMContentLoaded',function(){
    document.getElementById('model_1').addEventListener('click',function(){
        window.location.href='/second';
    });
    document.getElementById('model_2').addEventListener('click',function(){
        window.location.href='/model_two';
    });
    
});